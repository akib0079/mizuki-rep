import { Router } from 'express'
import { z } from 'zod'
import { DateTime } from 'luxon'
import { STUDIO_TZ, workshopPolicy } from '@mizuki/shared'
import {
  courseTypeInputSchema,
  emailTemplateInputSchema,
  emailTemplateKeySchema,
  scheduleRuleInputSchema,
  sendTestEmailSchema,
} from '@mizuki/shared'
import {
  AuditLogModel,
  CourseSeriesModel,
  CourseTypeModel,
  EmailTemplateModel,
  PackageModel,
  OutboxModel,
  PushSubscriptionModel,
  ScheduleRuleModel,
  SessionModel,
} from '../../models/index.js'
import { getSeriesAvailability } from '../../services/seriesService.js'
import { buildDashboard } from '../../services/dashboardService.js'
import { hoursSinceLastBackup, listBackups, readBackup, runBackup } from '../../services/backupService.js'
import {
  DEFAULT_TEMPLATES,
  renderTemplate,
  resetTemplate,
  usesCurrentBranding,
} from '../../services/emailTemplates.js'
import {
  checkEmailKey,
  checkTelegram,
  clearFailedMessages,
  drainOutbox,
  sendDirectEmail,
  sendTelegramTest,
} from '../../services/mailer.js'
import {
  PLAIN_KEYS,
  SECRET_KEYS,
  clearSecret,
  describeSecret,
  getPlain,
  setPlain,
  setSecret,
} from '../../services/secretStore.js'
import { materializeSessions } from '../../services/scheduleService.js'
import {
  notificationRecipients,
  telegramConfigured,
} from '../../services/adminNotificationService.js'
import { sendDailyDigest } from '../../jobs/index.js'
import { schedulerStatus } from '../../scheduler.js'
import { findSeatDrift, repairSeatDrift } from '../../services/seatService.js'
import { recordAudit } from '../../services/auditService.js'
import { actorOf } from '../../middleware/auth.js'
import { asyncRoute } from '../../middleware/errorHandler.js'
import { AppError, NotFoundError } from '../../errors.js'
import { config, bookingPageUrl, myBookingsUrl } from '../../config.js'
import { productPatchFromUrl, refreshWooProductSnapshots } from '../../services/wooProductService.js'
import { getStudioContact, saveStudioContact } from '../../services/studioContactService.js'

/** Courses, recurring timetable rules, message wording, and the maintenance levers. */
export const adminSettingsRouter: Router = Router()

const studioContactSchema = z.object({
  name: z.string().trim().min(1).max(120),
  address: z.string().trim().min(1).max(300),
  phone: z.string().trim().min(3).max(50),
  email: z.string().trim().email().max(200),
})

adminSettingsRouter.get('/studio-contact', asyncRoute(async (_req, res) => {
  res.json({ contact: await getStudioContact() })
}))

adminSettingsRouter.put('/studio-contact', asyncRoute(async (req, res) => {
  const contact = studioContactSchema.parse(req.body)
  const actor = actorOf(req)
  const before = await getStudioContact()
  await saveStudioContact(contact, actor)
  await recordAudit({ actor, action: 'studio.contact.update', entity: 'Setting', before, after: contact })
  res.json({ contact })
}))

// --- Dashboard --------------------------------------------------------------

/** Everything the landing page shows, in one call. */
adminSettingsRouter.get(
  '/dashboard',
  asyncRoute(async (_req, res) => {
    res.json(await buildDashboard())
  }),
)

// --- Courses ----------------------------------------------------------------

adminSettingsRouter.get(
  '/courses',
  asyncRoute(async (_req, res) => {
    const courses = await CourseTypeModel.find().sort({ sortOrder: 1 }).lean()
    await refreshWooProductSnapshots(courses)
    res.json({ courses: courses.map((c) => ({ ...c, id: String(c._id) })) })
  }),
)

adminSettingsRouter.post(
  '/courses',
  asyncRoute(async (req, res) => {
    const input = courseTypeInputSchema.parse(req.body)
    const product = await productPatchFromUrl(input.wooProductUrl, input.bookingMode === 'paid' && input.checkoutFlow !== 'product_page')
    const course = await CourseTypeModel.create({ ...input, ...product })
    res.status(201).json({ course: { id: String(course._id), name: course.name } })
  }),
)

/**
 * Editing a course changes policy for every class of that course, including ones already booked —
 * so the reschedule window is audited when it moves.
 */
adminSettingsRouter.patch(
  '/courses/:id',
  asyncRoute(async (req, res) => {
    const input = courseTypeInputSchema.partial().parse(req.body)

    const before = await CourseTypeModel.findById(req.params.id).lean()
    if (!before) throw new NotFoundError('Course')

    const product = input.wooProductUrl !== undefined || input.checkoutFlow !== undefined
      ? await productPatchFromUrl(input.wooProductUrl ?? before.wooProductUrl, (input.bookingMode ?? before.bookingMode) === 'paid' && (input.checkoutFlow ?? before.checkoutFlow) !== 'product_page')
      : {}
    const course = await CourseTypeModel.findByIdAndUpdate(req.params.id, { $set: { ...input, ...product } }, { new: true })

    /*
     * A calendar class stores its own title so special sessions can be named differently. That
     * also meant renaming a course left every ordinary future class showing the old name. Move
     * only exact matches, preserving intentionally custom titles such as "Morning workshop".
     */
    if (input.name !== undefined && input.name !== before.name) {
      await Promise.all([
        SessionModel.updateMany(
          { courseTypeId: before._id, title: before.name, status: 'scheduled' },
          { $set: { title: input.name } },
        ),
        ScheduleRuleModel.updateMany(
          { courseTypeId: before._id, title: before.name },
          { $set: { title: input.name } },
        ),
      ])

      await recordAudit({
        actor: actorOf(req),
        action: 'course.rename',
        entity: 'CourseType',
        entityId: course!._id,
        before: { name: before.name },
        after: { name: input.name },
      })
    }

    if (input.rescheduleCutoffHours !== undefined && input.rescheduleCutoffHours !== before.rescheduleCutoffHours) {
      await recordAudit({
        actor: actorOf(req),
        action: 'course.rescheduleWindowChanged',
        entity: 'CourseType',
        entityId: course!._id,
        before: { rescheduleCutoffHours: before.rescheduleCutoffHours },
        after: { rescheduleCutoffHours: input.rescheduleCutoffHours },
      })
    }

    res.json({ course: { id: String(course!._id), name: course!.name } })
  }),
)

/**
 * Remove a course entirely.
 *
 * Archiving is the right answer almost every time: it takes the course off the website and keeps
 * every class and every student record it is attached to. This is for the other case — a course
 * added by mistake, or one set up twice — where archiving leaves a wrong row on the settings page
 * forever.
 *
 * So it refuses whenever anything points at the course, and says what does. Deleting a course
 * with classes behind it would orphan every one of them: sessions whose colour, rules and name
 * come from a row that no longer exists, and bookings on those sessions that students can still
 * see. Better to be told "archive it instead" than to find that out afterwards.
 */
adminSettingsRouter.delete(
  '/courses/:id',
  asyncRoute(async (req, res) => {
    const course = await CourseTypeModel.findById(req.params.id)
    if (!course) throw new NotFoundError('Course')

    const [sessionCount, ruleCount, packageCount, seriesCount] = await Promise.all([
      SessionModel.countDocuments({ courseTypeId: course._id }),
      ScheduleRuleModel.countDocuments({ courseTypeId: course._id }),
      PackageModel.countDocuments({ courseTypeId: course._id }),
      CourseSeriesModel.countDocuments({ courseTypeId: course._id }),
    ])

    const blockers: string[] = []
    if (sessionCount) blockers.push(`${sessionCount} class${sessionCount === 1 ? '' : 'es'}`)
    if (ruleCount) blockers.push(`${ruleCount} weekly timetable rule${ruleCount === 1 ? '' : 's'}`)
    if (packageCount) blockers.push(`${packageCount} course package${packageCount === 1 ? '' : 's'}`)
    if (seriesCount) blockers.push(`${seriesCount} set course${seriesCount === 1 ? '' : 's'}`)

    if (blockers.length) {
      throw new AppError(
        409,
        'course_in_use',
        `${course.name} still has ${blockers.join(', ')} attached, so deleting it would leave them ` +
          `pointing at nothing. Archive it instead — it disappears from the website and everything is kept.`,
      )
    }

    await recordAudit({
      actor: actorOf(req),
      action: 'course.delete',
      entity: 'CourseType',
      entityId: course._id,
      before: { name: course.name, slug: course.slug },
      reason: 'Deleted from the courses page',
    })

    await course.deleteOne()

    res.json({ deleted: true, name: course.name })
  }),
)

// --- Recurring timetable rules ----------------------------------------------

adminSettingsRouter.get(
  '/schedule-rules',
  asyncRoute(async (_req, res) => {
    const rules = await ScheduleRuleModel.find().sort({ startTime: 1 }).lean()
    res.json({ rules: rules.map((r) => ({ ...r, id: String(r._id) })) })
  }),
)

adminSettingsRouter.post(
  '/schedule-rules',
  asyncRoute(async (req, res) => {
    const input = scheduleRuleInputSchema.parse(req.body)
    const rule = await ScheduleRuleModel.create(input)

    // Fill the calendar straight away, so a new weekly slot shows up without waiting for cron.
    const generated = await materializeSessions()

    res.status(201).json({ rule: { id: String(rule._id) }, sessionsGenerated: generated.created })
  }),
)

adminSettingsRouter.patch(
  '/schedule-rules/:id',
  asyncRoute(async (req, res) => {
    // `.innerType()` reaches past the cross-field refinement, which cannot be made partial.
    const input = scheduleRuleInputSchema.innerType().partial().parse(req.body)
    const rule = await ScheduleRuleModel.findByIdAndUpdate(req.params.id, { $set: input }, { new: true })
    if (!rule) throw new NotFoundError('Schedule rule')
    res.json({ rule: { id: String(rule._id) } })
  }),
)

/**
 * Stopping a rule stops future generation only. Classes it already produced stay exactly as they
 * are, because students are booked into them — removing a template must never delete a booking.
 */
adminSettingsRouter.delete(
  '/schedule-rules/:id',
  asyncRoute(async (req, res) => {
    const rule = await ScheduleRuleModel.findByIdAndUpdate(req.params.id, { $set: { active: false } }, { new: true })
    if (!rule) throw new NotFoundError('Schedule rule')

    await recordAudit({
      actor: actorOf(req),
      action: 'scheduleRule.deactivate',
      entity: 'ScheduleRule',
      entityId: rule._id,
    })

    res.json({ ok: true, note: 'Future classes will no longer be generated. Existing classes are unchanged.' })
  }),
)

/** Force a generation pass — the admin console's "fill the calendar" button. */
adminSettingsRouter.post(
  '/schedule-rules/generate',
  asyncRoute(async (req, res) => {
    const { from, to } = z.object({ from: z.string().optional(), to: z.string().optional() }).parse(req.body)
    const result = await materializeSessions({ from, to })
    res.json(result)
  }),
)

// --- Set courses (the Autumn Ikebana Course and anything like it) ------------

adminSettingsRouter.get(
  '/series',
  asyncRoute(async (_req, res) => {
    const all = await CourseSeriesModel.find().sort({ createdAt: -1 }).lean()
    const detailed = await Promise.all(
      all.map(async (s) => ({
        ...(await getSeriesAvailability(s._id)),
        wooProductId: s.wooProductId,
        active: s.active,
        description: s.description,
      })),
    )
    res.json({ series: detailed })
  }),
)

const seriesInputSchema = z.object({
  name: z.string().trim().min(1).max(120),
  courseTypeId: z.string().regex(/^[0-9a-fA-F]{24}$/),
  sessionIds: z.array(z.string().regex(/^[0-9a-fA-F]{24}$/)).min(1),
  wooProductId: z.number().int().positive().nullable().default(null),
  description: z.string().max(2000).default(''),
  active: z.boolean().default(true),
})

adminSettingsRouter.post(
  '/series',
  asyncRoute(async (req, res) => {
    const input = seriesInputSchema.parse(req.body)
    const series = await CourseSeriesModel.create(input)

    await recordAudit({
      actor: actorOf(req),
      action: 'series.create',
      entity: 'CourseSeries',
      entityId: series._id,
      after: { name: input.name, sessions: input.sessionIds.length },
    })

    res.status(201).json({ series: { id: String(series._id), name: series.name } })
  }),
)

/**
 * Mostly used to attach the shop product. Until that is set, buying the course in the shop
 * cannot book anything — the order arrives with no way to tell what it was for.
 */
adminSettingsRouter.patch(
  '/series/:id',
  asyncRoute(async (req, res) => {
    const input = seriesInputSchema.partial().parse(req.body)
    const series = await CourseSeriesModel.findByIdAndUpdate(req.params.id, { $set: input }, { new: true })
    if (!series) throw new NotFoundError('Course')

    await recordAudit({
      actor: actorOf(req),
      action: 'series.update',
      entity: 'CourseSeries',
      entityId: series._id,
      after: input,
    })

    res.json({ series: { id: String(series._id), name: series.name, wooProductId: series.wooProductId } })
  }),
)

// --- Email templates --------------------------------------------------------

adminSettingsRouter.get(
  '/templates',
  asyncRoute(async (_req, res) => {
    const overrides = await EmailTemplateModel.find().lean()
    const byKey = new Map(overrides.map((t) => [t.key, t]))

    res.json({
      templates: Object.entries(DEFAULT_TEMPLATES).map(([key, def]) => {
        const override = byKey.get(key)
        const bodyHtml = override?.bodyHtml ?? def.bodyHtml
        return {
          key,
          label: def.label,
          description: def.description,
          variables: def.variables,
          subject: override?.subject ?? def.subject,
          bodyHtml,
          bodyText: override?.bodyText ?? def.bodyText,
          isCustomised: Boolean(override) && override!.updatedBy !== 'seed',
          /*
           * Wording the studio wrote themselves is never overwritten by a deploy, so a design
           * change reaches every email except theirs. Saying so is the difference between an
           * offer to update it and one message in fifteen quietly looking wrong.
           */
          brandingIsCurrent: usesCurrentBranding(bodyHtml),
        }
      }),
    })
  }),
)

adminSettingsRouter.put(
  '/templates/:key',
  asyncRoute(async (req, res) => {
    const key = emailTemplateKeySchema.parse(req.params.key)
    const input = emailTemplateInputSchema.parse(req.body)

    await EmailTemplateModel.findOneAndUpdate(
      { key },
      { $set: { ...input, updatedBy: actorOf(req) } },
      { upsert: true },
    )

    res.json({ ok: true })
  }),
)

adminSettingsRouter.post(
  '/templates/:key/reset',
  asyncRoute(async (req, res) => {
    const key = emailTemplateKeySchema.parse(req.params.key)
    await resetTemplate(key)
    res.json({ ok: true })
  }),
)

/** Preview with realistic sample values, so the studio sees what a student would receive. */
adminSettingsRouter.post(
  '/templates/:key/preview',
  asyncRoute(async (req, res) => {
    const key = emailTemplateKeySchema.parse(req.params.key)
    // The editor sends what is on screen; an empty body still previews what is stored.
    const draft = z
      .object({
        subject: z.string().max(200).optional(),
        bodyHtml: z.string().max(50_000).optional(),
        bodyText: z.string().max(20_000).optional(),
      })
      .parse(req.body ?? {})

    const rendered = await renderTemplate(key, await sampleVars(key), draft)
    res.json(rendered)
  }),
)

adminSettingsRouter.post(
  '/templates/:key/test',
  asyncRoute(async (req, res) => {
    const key = emailTemplateKeySchema.parse(req.params.key)
    const { to } = sendTestEmailSchema.parse(req.body)

    const rendered = await renderTemplate(key, await sampleVars(key))
    await sendDirectEmail(to, `[Test] ${rendered.subject}`, rendered.html, rendered.text)

    res.json({ ok: true, sentTo: to })
  }),
)

const SAMPLE_VARS: Record<string, string | number> = {
  studentName: 'Aiko Tan',
  studentEmail: 'aiko@example.com',
  studentPhone: '+65 9123 4567',
  courseName: 'Ikebana',
  sessionTitle: 'Ikebana Workshop — Morning',
  sessionDate: 'Sat 22 Aug 2026',
  sessionTimeRange: '10:00 AM – 12:30 PM',
  sessionDuration: '2h 30m',
  rescheduleDeadline: 'Wed 19 Aug 2026, 10:00 AM',
  previousSessionDate: 'Sun 16 Aug 2026',
  previousSessionTimeRange: '2:30 PM – 5:00 PM',
  packageLine: 'You have 6 of 8 IFDA sessions remaining in your course package.',
  partySizeLine: 'Participants: 3',
  cancelReasonLine: 'Reason: the studio is closed for outside work.',
  sessionsRemaining: 1,
  packageExpiryDate: 'Sat 14 Nov 2026',
  bookingSource: 'website',
  seatsTaken: 5,
  seatsLeft: 3,
  capacity: 8,
  todayDate: 'Saturday 22 August 2026',
  sessionCount: 3,
  studentCount: 11,
  sessionListHtml: '<ul><li><strong>10:00 AM</strong> — Ikebana Workshop: 5/8 booked</li></ul>',
  sessionListText: '• 10:00 AM — Ikebana Workshop: 5/8 booked',
  magicLinkUrl: `${config.PUBLIC_API_URL}/api/auth/magic-link/verify?token=sample`,
  // The real setting, so the preview cannot show a lifetime the links do not have.
  expiryHours: config.MAGIC_LINK_TTL_HOURS,
  myBookingsUrl: myBookingsUrl(),
  bookingUrl: bookingPageUrl(),
  adminSessionUrl: `${config.PUBLIC_API_URL}/admin/calendar`,
  adminCalendarUrl: `${config.PUBLIC_API_URL}/admin/calendar`,
  siteUrl: config.PUBLIC_SITE_URL,
}

/**
 * The one sample line that cannot be shared.
 *
 * `packageLine` is written to the reader, and the admin alerts have a different reader — previewing
 * them with the student's wording showed the studio "You have 6 of 8 sessions remaining" about
 * somebody else's balance, which is exactly the mistake the live templates used to make.
 */
async function sampleVars(key: string): Promise<Record<string, string | number>> {
  const contact = await getStudioContact()
  const values = { ...SAMPLE_VARS, studioPhone: contact.phone, venueAddress: contact.address, workshopPolicyLine: workshopPolicy(contact.phone) }
  if (!key.startsWith('admin_')) return values
  return {
    ...values,
    packageLine: 'They have 6 of 8 IFDA sessions left in their course package.',
  }
}

// --- Web push enrolment -----------------------------------------------------

adminSettingsRouter.get('/push/key', (_req, res) => {
  res.json({ publicKey: config.VAPID_PUBLIC_KEY ?? null })
})

adminSettingsRouter.post(
  '/push/subscribe',
  asyncRoute(async (req, res) => {
    const subscription = z
      .object({
        endpoint: z.string().url(),
        keys: z.object({ p256dh: z.string(), auth: z.string() }),
      })
      .parse(req.body)

    await PushSubscriptionModel.findOneAndUpdate(
      { endpoint: subscription.endpoint },
      {
        $set: {
          adminUserId: req.admin!._id,
          keys: subscription.keys,
          userAgent: req.headers['user-agent'] ?? '',
          failureCount: 0,
        },
      },
      { upsert: true },
    )

    res.status(201).json({ ok: true })
  }),
)

// --- Connected services -----------------------------------------------------

/**
 * The keys the studio can change themselves.
 *
 * Only ever reports whether each is set and a masked hint — never the value. The screen exists
 * to answer "is the right key in there?", not to become a way of reading secrets back out.
 */
adminSettingsRouter.get(
  '/integrations',
  asyncRoute(async (_req, res) => {
    const [email, telegramToken, telegramChat] = await Promise.all([
      describeSecret(SECRET_KEYS.resendApiKey, config.RESEND_API_KEY),
      describeSecret(SECRET_KEYS.telegramBotToken, config.TELEGRAM_BOT_TOKEN),
      describeSecret(SECRET_KEYS.telegramChatId, config.TELEGRAM_CHAT_ID),
    ])
    const [mailFrom, replyTo] = await Promise.all([
      getPlain(PLAIN_KEYS.mailFrom, config.MAIL_FROM),
      getPlain(PLAIN_KEYS.mailReplyTo, config.MAIL_REPLY_TO),
    ])
    res.json({ email, telegramToken, telegramChat, mailFrom, replyTo })
  }),
)

const secretInputSchema = z.object({ value: z.string().trim().min(1, 'Paste the key') })

/**
 * Why this address will not work, or null if it will.
 *
 * Deliberately permissive when Resend cannot be reached: refusing to save because a third party
 * is briefly unavailable would be worse than the mistake this guards against.
 */
async function senderProblem(from: string): Promise<string | null> {
  const domain = from.match(/@([^\s>]+)/)?.[1]?.toLowerCase()
  if (!domain) return 'That does not look like an email address. Use a form like Mizuki Flora <bookings@yourdomain.com>.'

  if (domain === 'resend.dev') {
    return 'That is Resend\'s shared test address — it only ever reaches the Resend account owner, so students and other admins get nothing. Use an address at a domain you have verified in Resend.'
  }

  const health = await checkEmailKey()
  if (!health.verifiedDomains.length) return null

  const usable = health.verifiedDomains.some((d) => domain === d || domain.endsWith(`.${d}`))
  if (usable) return null

  return `${domain} is not verified in Resend, so nothing sent from it will arrive. Verified right now: ${health.verifiedDomains.join(', ')} — for example bookings@${health.verifiedDomains[0]}.`
}

const PLAIN_SETTINGS: Record<string, (typeof PLAIN_KEYS)[keyof typeof PLAIN_KEYS]> = {
  'mail-from': PLAIN_KEYS.mailFrom,
  'mail-reply-to': PLAIN_KEYS.mailReplyTo,
}

/**
 * The sending address.
 *
 * Editable because it has to change at a predictable moment: Resend refuses to send from a
 * domain until its DNS is verified, so testing before that means sending from their sandbox
 * address and switching afterwards. That should not need a redeploy.
 */
adminSettingsRouter.put(
  '/mail/:name',
  asyncRoute(async (req, res) => {
    const key = PLAIN_SETTINGS[req.params.name!]
    if (!key) throw new NotFoundError('Setting')

    const { value } = z.object({ value: z.string().trim().max(200) }).parse(req.body)

    /*
     * Refuse a sending address that cannot deliver.
     *
     * Getting this wrong is silent and total: mail from an unverified domain, or from Resend's
     * shared test address, is rejected for every recipient except the Resend account owner. The
     * console reports the key as fine, the queue drains, and nobody hears anything — which is
     * exactly what happened here, for days. Checking at the moment of saving is the only point
     * where someone is present to be told.
     */
    if (key === PLAIN_KEYS.mailFrom) {
      const problem = await senderProblem(value)
      if (problem) throw new AppError(400, 'unusable_sender', problem)
    }

    if (key === PLAIN_KEYS.mailReplyTo) {
      const email = z.string().email().parse(value)
      await saveStudioContact({ ...(await getStudioContact()), email }, actorOf(req))
    } else {
      await setPlain(key, value, actorOf(req))
    }

    await recordAudit({ actor: actorOf(req), action: 'mail.update', entity: 'Setting', reason: `${req.params.name} = ${value}` })
    res.json({ ok: true, value })
  }),
)

const EDITABLE_SECRETS: Record<string, (typeof SECRET_KEYS)[keyof typeof SECRET_KEYS]> = {
  resend: SECRET_KEYS.resendApiKey,
  'telegram-token': SECRET_KEYS.telegramBotToken,
  'telegram-chat': SECRET_KEYS.telegramChatId,
}

adminSettingsRouter.put(
  '/integrations/:name',
  asyncRoute(async (req, res) => {
    const key = EDITABLE_SECRETS[req.params.name!]
    if (!key) throw new NotFoundError('Setting')

    const { value } = secretInputSchema.parse(req.body)

    /*
     * A Telegram chat id is a number — negative for groups and channels. A @username is not one,
     * and the bot's own @username least of all: a bot cannot message itself.
     *
     * Saved without complaint, that produced a console showing everything configured and a phone
     * that never buzzed, with the failure recorded only as "no transport configured". Caught
     * here, while somebody is looking at the screen.
     */
    if (key === SECRET_KEYS.telegramChatId && !/^-?\d+$/.test(value)) {
      throw new AppError(
        400,
        'not_a_chat_id',
        value.startsWith('@')
          ? 'That is a username, not a chat id. Press "Find my chat" below — the bot can only tell ' +
            'us the id after somebody has opened Telegram and pressed Start on it.'
          : 'A Telegram chat id is a number, like 123456789 or -1001234567890.',
      )
    }
    await setSecret(key, value, actorOf(req))

    // The value is never logged or audited — only that it changed, and by whom.
    await recordAudit({ actor: actorOf(req), action: 'integration.update', entity: 'Setting', reason: req.params.name })

    res.json({ ok: true, status: await describeSecret(key) })
  }),
)

/** Revert to whatever the server was deployed with. */
adminSettingsRouter.delete(
  '/integrations/:name',
  asyncRoute(async (req, res) => {
    const key = EDITABLE_SECRETS[req.params.name!]
    if (!key) throw new NotFoundError('Setting')

    await clearSecret(key, actorOf(req))
    await recordAudit({ actor: actorOf(req), action: 'integration.clear', entity: 'Setting', reason: req.params.name })

    res.json({ ok: true })
  }),
)

/** Check a key works without sending anything or spending quota. */
adminSettingsRouter.get(
  '/integrations/resend/check',
  asyncRoute(async (_req, res) => {
    res.json(await checkEmailKey())
  }),
)

/**
 * Forget failed messages.
 *
 * They cannot be resent, so this only clears the record. Offered because a permanent rejection
 * never retries: without it, one misconfigured afternoon leaves the console reporting a mail
 * problem forever, and an alert that is always on is an alert nobody reads.
 */
adminSettingsRouter.post(
  '/integrations/resend/clear-failures',
  asyncRoute(async (req, res) => {
    const cleared = await clearFailedMessages()
    await recordAudit({
      actor: actorOf(req),
      action: 'mail.clear_failures',
      entity: 'Outbox',
      reason: `Cleared ${cleared} failed message(s)`,
    })
    res.json({ cleared })
  }),
)

adminSettingsRouter.get(
  '/integrations/telegram/check',
  asyncRoute(async (_req, res) => {
    res.json(await checkTelegram())
  }),
)

/** Save the chat the bot should message, chosen from the ones it can actually see. */
adminSettingsRouter.post(
  '/integrations/telegram/use-chat',
  asyncRoute(async (req, res) => {
    const { chatId } = z.object({ chatId: z.string().trim().min(1) }).parse(req.body)

    await setSecret(SECRET_KEYS.telegramChatId, chatId, actorOf(req))
    await recordAudit({
      actor: actorOf(req),
      action: 'settings.telegram_chat',
      entity: 'Setting',
      reason: `Telegram alerts now go to chat ${chatId}`,
    })

    res.json(await checkTelegram())
  }),
)

/** Prove it works now, rather than finding out at the next booking. */
adminSettingsRouter.post(
  '/integrations/telegram/test',
  asyncRoute(async (_req, res) => {
    res.json(await sendTelegramTest())
  }),
)

// --- Alerts to the studio ---------------------------------------------------

/**
 * Is the studio actually being told things?
 *
 * Every part of this was already knowable and none of it was in one place, which is how a daily
 * digest that had never once been sent went unnoticed: nothing was failing, so nothing showed up
 * as a failure. The three questions that matter are who it goes to, whether the timer that sends
 * it is running, and when each kind last went out — so they are answered together, on one screen.
 */
adminSettingsRouter.get(
  '/alerts',
  asyncRoute(async (_req, res) => {
    const scheduler = schedulerStatus()
    const studioNow = DateTime.now().setZone(STUDIO_TZ)

    const [recipients, telegram, lastDigest, lastReminder, lastBooking, queued] = await Promise.all([
      notificationRecipients(),
      telegramConfigured(),
      lastSentAt('admin_daily_digest'),
      lastSentAt('reminder_2day'),
      lastSentAt('admin_new_booking'),
      OutboxModel.countDocuments({ status: 'pending' }),
    ])

    res.json({
      recipients,
      channels: {
        email: recipients.length > 0,
        telegram,
        webPush: Boolean(config.VAPID_PUBLIC_KEY && config.VAPID_PRIVATE_KEY),
      },
      scheduler: {
        enabled: scheduler.enabled,
        everyMinutes: scheduler.everyMinutes,
        lastRunAt: scheduler.lastRunAt,
        minutesSinceLastRun: scheduler.minutesSinceLastRun,
        // A timer that has quietly stopped looks exactly like one that is working.
        stale:
          scheduler.enabled &&
          scheduler.minutesSinceLastRun !== null &&
          scheduler.minutesSinceLastRun > 30,
        lastError: scheduler.lastError,
      },
      queued,
      studioTime: studioNow.toFormat('h:mm a, ccc d LLL'),
      digest: { sendHour: config.DIGEST_SEND_HOUR, lastSentAt: lastDigest },
      reminders: { sendHour: config.REMINDER_SEND_HOUR, lastSentAt: lastReminder },
      newBookings: { lastSentAt: lastBooking },
    })
  }),
)

/** When a message of this kind last actually left the building — not when it was queued. */
async function lastSentAt(type: string): Promise<Date | null> {
  const row = await OutboxModel.findOne({ type, status: 'sent' })
    .sort({ sentAt: -1 })
    .select('sentAt')
    .lean()
  return row?.sentAt ?? null
}

/**
 * Send this morning's digest right now.
 *
 * Waiting until tomorrow to find out whether a fix worked is not a test, it is a hope. This
 * queues the digest to everyone it would normally go to and drains the queue in the same
 * request, so the answer comes back as "sent to these three people" or as the reason it did not.
 */
adminSettingsRouter.post(
  '/alerts/digest-now',
  asyncRoute(async (req, res) => {
    const recipients = await notificationRecipients()
    if (recipients.length === 0) {
      throw new AppError(
        400,
        'no_recipients',
        'There is nobody to send it to. Add an admin, or an extra address, on the Team page.',
      )
    }

    const queued = await sendDailyDigest(new Date(), { force: true })
    const mail = await drainOutbox()

    await recordAudit({
      actor: actorOf(req),
      action: 'settings.digest_test',
      entity: 'Outbox',
      reason: `Sent today's digest to ${recipients.join(', ')}`,
    })

    res.json({ queued, sent: mail.sent, failed: mail.failed, recipients })
  }),
)

// --- Backups ----------------------------------------------------------------

adminSettingsRouter.get(
  '/backups',
  asyncRoute(async (_req, res) => {
    const [backups, ageHours] = await Promise.all([listBackups(), hoursSinceLastBackup()])
    res.json({ backups, ageHours, keep: config.BACKUP_KEEP })
  }),
)

adminSettingsRouter.post(
  '/backups/run',
  asyncRoute(async (req, res) => {
    const result = await runBackup()
    await recordAudit({ actor: actorOf(req), action: 'maintenance.backup', entity: 'Database', after: result })
    res.json(result)
  }),
)

/**
 * Download a backup.
 *
 * These contain student names, emails and phone numbers, so this sits behind the admin session
 * like everything else here, and the filename is validated rather than trusted — it arrives
 * from a URL and would otherwise be a path traversal.
 */
adminSettingsRouter.get(
  '/backups/:file',
  asyncRoute(async (req, res) => {
    try {
      const data = await readBackup(req.params.file!)
      res.setHeader('Content-Type', 'application/gzip')
      res.setHeader('Content-Disposition', `attachment; filename="${req.params.file}"`)
      res.send(data)
    } catch {
      throw new NotFoundError('Backup')
    }
  }),
)

// --- Maintenance ------------------------------------------------------------

adminSettingsRouter.get(
  '/audit',
  asyncRoute(async (req, res) => {
    const { limit } = z.object({ limit: z.coerce.number().min(1).max(200).default(100) }).parse(req.query)
    const entries = await AuditLogModel.find().sort({ createdAt: -1 }).limit(limit).lean()
    res.json({ entries })
  }),
)

/** Surface counter drift; repairing is a separate, deliberate click. */
adminSettingsRouter.get(
  '/seat-drift',
  asyncRoute(async (_req, res) => {
    res.json({ drift: await findSeatDrift() })
  }),
)

adminSettingsRouter.post(
  '/seat-drift/repair',
  asyncRoute(async (req, res) => {
    const drift = await findSeatDrift()
    const repaired = await repairSeatDrift(drift)

    await recordAudit({
      actor: actorOf(req),
      action: 'maintenance.repairSeatDrift',
      entity: 'Session',
      after: { repaired, drift },
    })

    res.json({ repaired, drift })
  }),
)
