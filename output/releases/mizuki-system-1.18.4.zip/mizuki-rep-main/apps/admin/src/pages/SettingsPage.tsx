import { useEffect, useState } from 'react'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { DateTime } from 'luxon'
import { STUDIO_TZ } from '@mizuki/shared'
import { ApiError, api, type Course } from '../api.js'
import { PasswordField } from '../components/PasswordField.js'
import { SkeletonLine } from '../components/Skeleton.js'

interface EmailHealth {
  ok: boolean
  message: string
  fix?: string
  from: string
  verifiedDomains: string[]
  recentFailures: { type: string; to: string; error: string; at: string }[]
}

interface TelegramHealth {
  ok: boolean
  message: string
  fix?: string
  botUsername: string
  hasToken: boolean
  hasChat: boolean
  chats: { id: string; label: string }[]
}

interface SeatDrift {
  sessionId: string
  dateKey: string
  title: string
  storedSeatsTaken: number
  actualSeatsTaken: number
}

interface StudioContact {
  name: string
  address: string
  phone: string
  email: string
}

function StudioContactCard({ onMessage }: { onMessage: (m: { kind: 'ok' | 'danger'; text: string }) => void }) {
  const queryClient = useQueryClient()
  const [draft, setDraft] = useState<StudioContact | null>(null)
  const contactQuery = useQuery({
    queryKey: ['studio-contact'],
    queryFn: () => api.get<{ contact: StudioContact }>('/api/admin/settings/studio-contact'),
  })

  useEffect(() => {
    if (contactQuery.data?.contact) setDraft(contactQuery.data.contact)
  }, [contactQuery.data])

  const save = useMutation({
    mutationFn: (contact: StudioContact) => api.put<{ contact: StudioContact }>('/api/admin/settings/studio-contact', contact),
    onSuccess: (result) => {
      setDraft(result.contact)
      void queryClient.invalidateQueries({ queryKey: ['integrations'] })
      onMessage({ kind: 'ok', text: 'Studio details saved.' })
    },
    onError: (err) => onMessage({ kind: 'danger', text: err instanceof ApiError ? err.message : 'Could not save studio details.' }),
  })

  return (
    <div className="card">
      <h2 className="card-title">Studio details</h2>
      <p className="card-sub">Your default details appear on the booking page, in student emails and in calendar invitations. Changing the default address updates classes without their own venue. Set a different venue on an individual class when needed.</p>
      {contactQuery.isError && <div className="banner banner-danger">Could not load studio details. Please refresh.</div>}
      {draft && (
        <form onSubmit={(event) => { event.preventDefault(); save.mutate(draft) }}>
          <div className="field-row">
            <label className="field"><span>Studio name</span><input required maxLength={120} value={draft.name} onChange={(event) => setDraft({ ...draft, name: event.target.value })} /></label>
            <label className="field"><span>Contact email</span><input required type="email" maxLength={200} value={draft.email} onChange={(event) => setDraft({ ...draft, email: event.target.value })} /></label>
          </div>
          <div className="field-row">
            <label className="field"><span>Default address</span><input required maxLength={300} value={draft.address} onChange={(event) => setDraft({ ...draft, address: event.target.value })} /></label>
            <label className="field"><span>Phone and WhatsApp</span><input required type="tel" maxLength={50} value={draft.phone} onChange={(event) => setDraft({ ...draft, phone: event.target.value })} /></label>
          </div>
          <p className="field-hint">The contact email is shown to students and receives replies. Booking alert recipients are managed in Team. The sending address is in Connected services below.</p>
          <button className="btn btn-primary" type="submit" disabled={save.isPending}>{save.isPending ? 'Saving…' : 'Save studio details'}</button>
        </form>
      )}
    </div>
  )
}

/** Course policy, phone alerts, and the maintenance levers. */
export function SettingsPage({ totpEnabled }: { totpEnabled: boolean }) {
  const queryClient = useQueryClient()
  const [message, setMessage] = useState<{ kind: 'ok' | 'danger'; text: string } | null>(null)

  const coursesQuery = useQuery({
    queryKey: ['courses'],
    queryFn: () => api.get<{ courses: Course[] }>('/api/admin/settings/courses'),
  })

  const driftQuery = useQuery({
    queryKey: ['seat-drift'],
    queryFn: () => api.get<{ drift: SeatDrift[] }>('/api/admin/settings/seat-drift'),
  })

  const courseMutation = useMutation({
    mutationFn: (input: { id: string; patch: Partial<Course> }) =>
      api.patch(`/api/admin/settings/courses/${input.id}`, input.patch),
    onSuccess: () => {
      setMessage({ kind: 'ok', text: 'Saved.' })
      void queryClient.invalidateQueries({ queryKey: ['courses'] })
    },
    onError: (err) => setMessage({ kind: 'danger', text: err instanceof ApiError ? err.message : 'Could not save.' }),
  })

  const repairMutation = useMutation({
    mutationFn: () => api.post<{ repaired: number }>('/api/admin/settings/seat-drift/repair'),
    onSuccess: (data) => {
      setMessage({ kind: 'ok', text: `Corrected ${data.repaired} class(es).` })
      void queryClient.invalidateQueries({ queryKey: ['seat-drift'] })
    },
  })

  const generateMutation = useMutation({
    mutationFn: () => api.post<{ created: number }>('/api/admin/settings/schedule-rules/generate', {}),
    onSuccess: (data) => {
      setMessage({ kind: 'ok', text: `Added ${data.created} class(es) from your weekly timetable.` })
      void queryClient.invalidateQueries({ queryKey: ['admin-sessions'] })
    },
  })

  return (
    <>
      <div className="page-head">
        <div>
          <h1>Settings</h1>
          <p>Studio contact details, course rules, alerts and maintenance.</p>
        </div>
      </div>

      {message && <div className={`banner banner-${message.kind}`}>{message.text}</div>}

      <StudioContactCard onMessage={setMessage} />

      <div className="card">
        <h2 className="card-title">Courses</h2>
        <p className="card-sub">
          How each course is paid for, and how late a student may change their booking.
        </p>

        <div className="table-wrap">
          <table className="table">
            <thead>
              <tr>
                <th>Course</th>
                <th>Booked with</th>
                <th>Shop product link</th>
                <th>Confirm by hand</th>
                <th>Notice to change</th>
                <th>Default class size</th>
                <th />
              </tr>
            </thead>
            <tbody>
              {(coursesQuery.data?.courses ?? []).map((c) => (
                <tr key={c.id} className={c.active ? '' : 'row-inactive'}>
                  <td>
                    <span className="legend-dot" style={{ background: c.colour, display: 'inline-block', marginRight: 8 }} />
                    <strong>{c.name}</strong>
                  </td>
                  <td>
                    <span className="pill pill-muted">
                      {c.bookingMode === 'package' ? 'Course package' : c.bookingMode === 'paid' ? 'Shop payment' : 'Free'}
                    </span>
                  </td>
                  <td>
                    {/*
                      Empty is meaningful, not merely unset: with no product the shop has nothing to
                      sell for this course, so a paid booking cannot be completed. Saying so beats
                      an empty box that looks finished.
                    */}
                    <input
                      type="url"
                      className="btn btn-sm"
                      style={{ width: 240 }}
                      placeholder={c.bookingMode === 'free' ? 'Not needed' : 'https://mizuki.com.sg/product/…'}
                      defaultValue={c.wooProductUrl ?? ''}
                      disabled={c.bookingMode === 'free'}
                      onBlur={(e) => {
                        const raw = e.target.value.trim()
                        if (raw !== (c.wooProductUrl ?? '')) {
                          courseMutation.mutate({ id: c.id, patch: { wooProductUrl: raw } as Partial<Course> })
                        }
                      }}
                    />
                    {c.wooPriceText && <div className="small muted">{c.wooProductName || 'WooCommerce product'} · {c.wooPriceText}</div>}
                    {c.bookingMode === 'paid' && (
                      <label className="small muted" style={{ display: 'block', marginTop: 6 }}>
                        Checkout route{' '}
                        <select
                          value={c.checkoutFlow ?? 'calendar_checkout'}
                          onChange={(e) => courseMutation.mutate({ id: c.id, patch: { checkoutFlow: e.target.value } as Partial<Course> })}
                        >
                          <option value="calendar_checkout">Calendar then payment</option>
                          <option value="product_page">Product page options</option>
                        </select>
                      </label>
                    )}
                    {c.bookingMode !== 'free' && !c.wooProductUrl && (
                      <div className="small" style={{ color: 'var(--danger, #b3382c)' }}>
                        Not on sale yet
                      </div>
                    )}
                  </td>
                  <td>
                    <label className="switch-label">
                      <input
                        type="checkbox"
                        checked={c.requiresManualConfirmation}
                        onChange={(e) =>
                          courseMutation.mutate({
                            id: c.id,
                            patch: { requiresManualConfirmation: e.target.checked } as Partial<Course>,
                          })
                        }
                      />
                      <span className="small muted">
                        {c.requiresManualConfirmation ? 'You approve each place' : 'Confirmed on payment'}
                      </span>
                    </label>
                  </td>
                  <td>
                    <select
                      className="btn btn-sm"
                      value={c.rescheduleCutoffHours}
                      onChange={(e) =>
                        courseMutation.mutate({
                          id: c.id,
                          patch: {
                            rescheduleCutoffHours: Number(e.target.value),
                            cancelCutoffHours: Number(e.target.value),
                          } as Partial<Course>,
                        })
                      }
                    >
                      <option value={0}>No restriction</option>
                      <option value={24}>24 hours</option>
                      <option value={48}>2 days</option>
                      <option value={72}>3 days</option>
                      <option value={168}>1 week</option>
                    </select>
                  </td>
                  <td>
                    <input
                      type="number"
                      min={1}
                      max={200}
                      className="btn btn-sm"
                      style={{ width: 74 }}
                      defaultValue={c.defaultCapacity}
                      onBlur={(e) => {
                        const value = Number(e.target.value)
                        if (value !== c.defaultCapacity) {
                          courseMutation.mutate({ id: c.id, patch: { defaultCapacity: value } as Partial<Course> })
                        }
                      }}
                    />
                  </td>
                  <td className="row-actions">
                    {/*
                      Archived, never deleted: courses are referenced by every class ever taught and
                      every package ever sold, and removing one would take the history with it.
                    */}
                    <button
                      type="button"
                      className={c.active ? 'link-btn link-danger' : 'link-btn'}
                      onClick={() =>
                        courseMutation.mutate({ id: c.id, patch: { active: !c.active } as Partial<Course> })
                      }
                    >
                      {c.active ? 'Archive' : 'Restore'}
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <NewCourseForm onMessage={setMessage} />

        <div className="banner banner-info" style={{ marginTop: 14, marginBottom: 0 }}>
          Changing the class size here only affects classes created from now on. To change one that
          already exists, open it on the calendar.
        </div>
      </div>

      <SetCoursesCard onMessage={setMessage} />

      <AlertsCard onMessage={setMessage} />

      <IntegrationsCard onMessage={setMessage} />

      <div className="card">
        <h2 className="card-title">Alerts on your phone</h2>
        <p className="card-sub">Get a notification the moment someone books.</p>
        <PushEnrolment onMessage={setMessage} />
      </div>

      <div className="card">
        <h2 className="card-title">Security</h2>
        <p className="card-sub">
          Two-factor sign-in is {totpEnabled ? 'on' : 'off'}.
          {!totpEnabled && ' Turning it on means a code from your phone is needed as well as your password.'}
        </p>
        <ChangePassword onMessage={setMessage} />
        <div style={{ marginTop: 18 }}>
          {!totpEnabled && <TotpSetup onMessage={setMessage} />}
        </div>
      </div>

      <BackupsCard onMessage={setMessage} />

      <AuditCard />

      <div className="card">
        <h2 className="card-title">Maintenance</h2>

        <div className="row" style={{ marginBottom: 14 }}>
          <button type="button" className="btn" onClick={() => generateMutation.mutate()} disabled={generateMutation.isPending}>
            {generateMutation.isPending ? 'Working…' : 'Fill the calendar from my weekly timetable'}
          </button>
        </div>

        {driftQuery.data && driftQuery.data.drift.length > 0 ? (
          <>
            <div className="banner banner-warn">
              {driftQuery.data.drift.length} class(es) have a places-taken count that does not match their
              bookings. This should not happen — worth a look before correcting it.
            </div>
            <div className="table-wrap">
              <table className="table">
                <thead>
                  <tr><th>Date</th><th>Class</th><th>Counter says</th><th>Bookings say</th></tr>
                </thead>
                <tbody>
                  {driftQuery.data.drift.map((d) => (
                    <tr key={d.sessionId}>
                      <td className="small">{d.dateKey}</td>
                      <td>{d.title}</td>
                      <td>{d.storedSeatsTaken}</td>
                      <td>{d.actualSeatsTaken}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <button type="button" className="btn btn-sm" style={{ marginTop: 12 }} onClick={() => repairMutation.mutate()}>
              Correct these counts
            </button>
          </>
        ) : (
          <div className="banner banner-ok" style={{ marginBottom: 0 }}>
            All place counts match their bookings.
          </div>
        )}
      </div>
    </>
  )
}

interface SeriesRow {
  seriesId: string
  name: string
  bookable: boolean
  placesLeft: number
  reason: string
  wooProductId: number | null
  active: boolean
  sessions: { id: string; title: string; startAt: string; seatsLeft: number; isFull: boolean }[]
}

/**
 * Set courses like the Autumn Ikebana Course, sold as one purchase covering several dates.
 *
 * The shop product id is the field that matters: until it is set, a course bought in the shop
 * arrives with no way to tell what it was for, and books nothing.
 */
function SetCoursesCard({ onMessage }: { onMessage: (m: { kind: 'ok' | 'danger'; text: string }) => void }) {
  const queryClient = useQueryClient()

  const { data } = useQuery({
    queryKey: ['admin-series'],
    queryFn: () => api.get<{ series: SeriesRow[] }>('/api/admin/settings/series'),
  })

  const linkMutation = useMutation({
    mutationFn: (input: { id: string; wooProductId: number | null }) =>
      api.patch(`/api/admin/settings/series/${input.id}`, { wooProductId: input.wooProductId }),
    onSuccess: () => {
      onMessage({ kind: 'ok', text: 'Saved.' })
      void queryClient.invalidateQueries({ queryKey: ['admin-series'] })
    },
    onError: (err) =>
      onMessage({ kind: 'danger', text: err instanceof ApiError ? err.message : 'Could not save.' }),
  })

  const rows = data?.series ?? []
  if (rows.length === 0) return null

  return (
    <div className="card">
      <h2 className="card-title">Set courses</h2>
      <p className="card-sub">
        Courses booked as a whole run rather than one date at a time. One purchase books every date.
      </p>

      {rows.map((row) => (
        <div key={row.seriesId} style={{ marginBottom: 18 }}>
          <div className="row" style={{ justifyContent: 'space-between' }}>
            <strong>{row.name}</strong>
            {row.bookable ? (
              <span className="pill pill-ok">{row.placesLeft} place(s) available</span>
            ) : (
              <span className="pill pill-danger">Not bookable</span>
            )}
          </div>

          {!row.bookable && row.reason && <div className="banner banner-warn" style={{ marginTop: 8 }}>{row.reason}</div>}

          <div className="table-wrap">
            <table className="table" style={{ marginTop: 8 }}>
              <tbody>
                {row.sessions.map((s) => (
                  <tr key={s.id}>
                    <td className="small">
                      {DateTime.fromISO(s.startAt).setZone(STUDIO_TZ).toFormat('ccc d LLL yyyy, h:mm a')}
                    </td>
                    <td style={{ textAlign: 'right' }}>
                      <span className={`pill ${s.isFull ? 'pill-danger' : 'pill-muted'}`}>
                        {s.isFull ? 'Full' : `${s.seatsLeft} left`}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <label className="field" style={{ maxWidth: 320, marginTop: 10 }}>
            <span>Shop product ID</span>
            <input
              type="number"
              defaultValue={row.wooProductId ?? ''}
              placeholder="e.g. 1234"
              onBlur={(e) => {
                const value = e.target.value.trim() ? Number(e.target.value) : null
                if (value !== row.wooProductId) linkMutation.mutate({ id: row.seriesId, wooProductId: value })
              }}
            />
            <div className="field-hint">
              {row.wooProductId
                ? 'Buying this product in the shop books all the dates above.'
                : 'Until this is set, buying this course in the shop will not book anything. Find the ID in WooCommerce → Products.'}
            </div>
          </label>
        </div>
      ))}
    </div>
  )
}

interface AuditEntry {
  _id: string
  actor: string
  action: string
  entity: string
  reason: string
  createdAt: string
}

/** A plain-English record of who changed what — the counterweight to letting the studio override its own rules. */
function AuditCard() {
  const [open, setOpen] = useState(false)

  const { data } = useQuery({
    queryKey: ['audit'],
    queryFn: () => api.get<{ entries: AuditEntry[] }>('/api/admin/settings/audit?limit=60'),
    enabled: open,
  })

  return (
    <div className="card">
      <div className="row" style={{ justifyContent: 'space-between' }}>
        <div>
          <h2 className="card-title">Recent changes</h2>
          <p className="card-sub" style={{ marginBottom: 0 }}>
            Every change to a class, a booking or a course package.
          </p>
        </div>
        <button type="button" className="btn btn-sm" onClick={() => setOpen(!open)}>
          {open ? 'Hide' : 'Show'}
        </button>
      </div>

      {open && (
        <div className="table-wrap">
          <table className="table" style={{ marginTop: 14 }}>
            <thead>
              <tr><th>When</th><th>What</th><th>Who</th></tr>
            </thead>
            <tbody>
              {(data?.entries ?? []).map((entry) => (
                <tr key={entry._id}>
                  <td className="small muted" style={{ whiteSpace: 'nowrap' }}>
                    {DateTime.fromISO(entry.createdAt).setZone(STUDIO_TZ).toFormat('d LLL, h:mm a')}
                  </td>
                  <td>
                    {describeAction(entry.action)}
                    {entry.reason && <div className="muted small">{entry.reason}</div>}
                  </td>
                  <td className="small muted">{entry.actor.replace(/^(admin|student|woo):/, '')}</td>
                </tr>
              ))}
              {data?.entries.length === 0 && (
                <tr><td colSpan={3} className="empty">Nothing recorded yet.</td></tr>
              )}
            </tbody>
          </table>
        </div>
      )}
    </div>
  )
}

/** Turn an action key into something readable. Overrides are called out, since that is the point. */
function describeAction(action: string): string {
  const labels: Record<string, string> = {
    'booking.create': 'Booking added',
    'booking.create.override': 'Booking added over the class size',
    'booking.cancel': 'Booking cancelled',
    'booking.reschedule': 'Booking moved',
    'booking.reschedule.override': 'Booking moved past the notice period',
    'session.create': 'Class added',
    'session.update': 'Class changed',
    'session.cancel': 'Class cancelled',
    'session.restore': 'Class put back on',
    'session.delete': 'Class deleted',
    'closedDate.create': 'Days marked closed',
    'closedDate.delete': 'Closed days reopened',
    'package.grant': 'Course package created',
    'package.adjust': 'Course package changed',
    'course.rescheduleWindowChanged': 'Notice period changed',
    'series.book': 'Set course booked',
    'series.create': 'Set course created',
    'series.update': 'Set course changed',
    'scheduleRule.deactivate': 'Weekly slot stopped',
    'maintenance.repairSeatDrift': 'Place counts corrected',
  }
  return labels[action] ?? action
}

interface SecretStatus { configured: boolean; hint: string; source: 'studio' | 'environment' | 'none' }
interface Integrations {
  email: SecretStatus
  telegramToken: SecretStatus
  telegramChat: SecretStatus
  mailFrom: string
  replyTo: string | null
}

/**
 * Connected services.
 *
 * Keys can be changed here rather than requiring a redeploy, which matters because rotating one
 * is something the studio may need to do on a bad day without a developer. Only a masked hint is
 * ever shown — the screen answers "is the right key in there?" without becoming a way to read a
 * secret back out.
 */
interface AlertsHealth {
  recipients: string[]
  channels: { email: boolean; telegram: boolean; webPush: boolean }
  scheduler: {
    enabled: boolean
    everyMinutes: number
    lastRunAt: string | null
    minutesSinceLastRun: number | null
    stale: boolean
    lastError: string | null
  }
  queued: number
  studioTime: string
  digest: { sendHour: number; lastSentAt: string | null }
  reminders: { sendHour: number; lastSentAt: string | null }
  newBookings: { lastSentAt: string | null }
}

/**
 * Is the studio actually being told things?
 *
 * Each part of this was knowable before and none of it was in one place, which is how a daily
 * digest that had never once been sent went unnoticed for months: nothing failed, so nothing
 * appeared as a failure, and the only symptom was an email that never came. What is missing from
 * a screen full of green ticks is a line saying when each kind of message last actually went out.
 */
function AlertsCard({ onMessage }: { onMessage: (m: { kind: 'ok' | 'danger'; text: string }) => void }) {
  const { data, isLoading, refetch } = useQuery({
    queryKey: ['alerts-health'],
    queryFn: () => api.get<AlertsHealth>('/api/admin/settings/alerts'),
    // The scheduler line goes stale on its own, so re-ask while the page is open.
    refetchInterval: 60_000,
  })

  const sendNow = useMutation({
    mutationFn: () =>
      api.post<{ sent: number; failed: number; recipients: string[] }>(
        '/api/admin/settings/alerts/digest-now',
      ),
    onSuccess: (r) => {
      onMessage(
        r.failed > 0
          ? { kind: 'danger', text: `${r.failed} copy/copies did not send — see Email below for why.` }
          : { kind: 'ok', text: `Today's summary sent to ${r.recipients.join(', ')}.` },
      )
      void refetch()
    },
    onError: (err) =>
      onMessage({ kind: 'danger', text: err instanceof ApiError ? err.message : 'Could not send it.' }),
  })

  if (isLoading || !data) {
    return (
      <div className="card">
        <h2 className="card-title">Alerts to you</h2>
        <SkeletonLine w="70%" />
      </div>
    )
  }

  const { scheduler } = data
  const hour = (h: number) => DateTime.fromObject({ hour: h }).toFormat('h a')

  return (
    <div className="card">
      <h2 className="card-title">Alerts to you</h2>
      <p className="card-sub">
        What the system sends the studio, and when each kind last went out. Studio time is{' '}
        {data.studioTime}.
      </p>

      {data.recipients.length === 0 ? (
        <div className="banner banner-danger">
          Nobody is set to receive alerts, so you will not hear about new bookings. Add someone on
          the Team page.
        </div>
      ) : (
        <p className="small">
          Going to <strong>{data.recipients.join(', ')}</strong>. Change this on the Team page.
        </p>
      )}

      {scheduler.stale && (
        <div className="banner banner-danger">
          Scheduled work last ran {scheduler.minutesSinceLastRun} minutes ago, and should run every{' '}
          {scheduler.everyMinutes}. Reminders and summaries are not going out.
          {scheduler.lastError ? ` Last error: ${scheduler.lastError}` : ''}
        </div>
      )}

      {!scheduler.enabled && (
        <div className="banner banner-warn">
          The built-in timer is switched off, so nothing is sent unless something else is calling
          the jobs endpoint.
        </div>
      )}

      <div className="table-wrap">
        <table className="table">
          <thead>
            <tr>
              <th>What</th>
              <th>When</th>
              <th>Last sent</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>
                <strong>Today&rsquo;s summary</strong>
                <div className="small muted">Every class today, and how many are booked.</div>
              </td>
              <td>{hour(data.digest.sendHour)} each morning</td>
              <td>
                <LastSent at={data.digest.lastSentAt} />
              </td>
            </tr>
            <tr>
              <td>
                <strong>New booking</strong>
                <div className="small muted">The moment someone books.</div>
              </td>
              <td>Straight away</td>
              <td>
                <LastSent at={data.newBookings.lastSentAt} />
              </td>
            </tr>
            <tr>
              <td>
                <strong>Student reminders</strong>
                <div className="small muted">Sent to students two days before their class.</div>
              </td>
              <td>{hour(data.reminders.sendHour)}, two days before</td>
              <td>
                <LastSent at={data.reminders.lastSentAt} />
              </td>
            </tr>
          </tbody>
        </table>
      </div>

      <div className="row" style={{ marginTop: 14, alignItems: 'center', gap: 12 }}>
        <button
          type="button"
          className="btn btn-quiet"
          disabled={sendNow.isPending || data.recipients.length === 0}
          onClick={() => sendNow.mutate()}
        >
          {sendNow.isPending ? 'Sending\u2026' : 'Send today\u2019s summary now'}
        </button>
        <span className="small muted">
          {/* Waiting until tomorrow to find out whether it works is not a test. */}
          Goes to everyone above, right now, without waiting for the morning.
        </span>
      </div>

      <ul className="pill-list" style={{ marginTop: 14 }}>
        <li className={`recipient-pill ${data.channels.email ? '' : 'is-off'}`}>
          Email {data.channels.email ? 'on' : 'off'}
        </li>
        <li className={`recipient-pill ${data.channels.telegram ? '' : 'is-off'}`}>
          Telegram {data.channels.telegram ? 'on' : 'off'}
        </li>
        <li className={`recipient-pill ${data.channels.webPush ? '' : 'is-off'}`}>
          Phone notifications {data.channels.webPush ? 'on' : 'off'}
        </li>
        {data.queued > 0 && <li className="recipient-pill">{data.queued} waiting to send</li>}
      </ul>
    </div>
  )
}

/** "3 hours ago", or the fact that it has never happened — which is the answer that matters. */
function LastSent({ at }: { at: string | null }) {
  if (!at) return <span className="pill pill-warn">Never</span>
  const when = DateTime.fromISO(at).setZone(STUDIO_TZ)
  return (
    <span title={when.toFormat('ccc d LLL yyyy, h:mm a')}>{when.toRelative() ?? when.toFormat('d LLL')}</span>
  )
}

function IntegrationsCard({ onMessage }: { onMessage: (m: { kind: 'ok' | 'danger'; text: string }) => void }) {
  const queryClient = useQueryClient()
  const [editing, setEditing] = useState<string | null>(null)
  const [value, setValue] = useState('')

  const { data } = useQuery({
    queryKey: ['integrations'],
    queryFn: () => api.get<Integrations>('/api/admin/settings/integrations'),
  })

  const save = useMutation({
    mutationFn: (input: { name: string; value: string }) =>
      api.put(`/api/admin/settings/integrations/${input.name}`, { value: input.value }),
    onSuccess: () => {
      setEditing(null)
      setValue('')
      onMessage({ kind: 'ok', text: 'Saved. New emails will use this key.' })
      void queryClient.invalidateQueries({ queryKey: ['integrations'] })
    },
    onError: (err) => onMessage({ kind: 'danger', text: err instanceof ApiError ? err.message : 'Could not save.' }),
  })

  /*
   * Checked on load, not only when a button is pressed.
   *
   * "Test email key" was opt-in, so a total outage sat here looking healthy — the key was valid,
   * which is what it reported, while every message was rejected for using a sender that could
   * not deliver. Nobody presses a test button on a screen that appears to be fine.
   */
  const health = useQuery({
    queryKey: ['email-health'],
    queryFn: () => api.get<EmailHealth>('/api/admin/settings/integrations/resend/check'),
  })

  const clearFailures = useMutation({
    mutationFn: () => api.post<{ cleared: number }>('/api/admin/settings/integrations/resend/clear-failures'),
    onSuccess: (r) => {
      onMessage({ kind: 'ok', text: `Cleared ${r.cleared} failed message(s).` })
      void health.refetch()
      // The dashboard raises the same count, so it has to forget them too.
      void queryClient.invalidateQueries({ queryKey: ['dashboard'] })
    },
  })

  /*
   * Telegram is the setting most likely to be half-done: a token on its own looks finished and
   * sends nothing, because Telegram will not let a bot message anyone who has not opened a
   * conversation with it first. Checked on load so that state is visible rather than discovered.
   */
  const telegram = useQuery({
    queryKey: ['telegram-health'],
    queryFn: () => api.get<TelegramHealth>('/api/admin/settings/integrations/telegram/check'),
  })

  const useChat = useMutation({
    mutationFn: (chatId: string) =>
      api.post<TelegramHealth>('/api/admin/settings/integrations/telegram/use-chat', { chatId }),
    onSuccess: (r) => {
      queryClient.setQueryData(['telegram-health'], r)
      void queryClient.invalidateQueries({ queryKey: ['integrations'] })
      onMessage({ kind: 'ok', text: 'Saved. Send a test to make sure it arrives.' })
    },
    onError: (err) => onMessage({ kind: 'danger', text: err instanceof ApiError ? err.message : 'Could not save.' }),
  })

  const telegramTest = useMutation({
    mutationFn: () => api.post<{ ok: boolean; message: string }>('/api/admin/settings/integrations/telegram/test'),
    onSuccess: (r) => onMessage({ kind: r.ok ? 'ok' : 'danger', text: r.message }),
  })

  const check = useMutation({
    mutationFn: () => api.get<EmailHealth>('/api/admin/settings/integrations/resend/check'),
    onSuccess: (r) => {
      void queryClient.setQueryData(['email-health'], r)
      onMessage({ kind: r.ok ? 'ok' : 'danger', text: r.message })
    },
  })

  const rows: { name: string; label: string; hint: string; status?: SecretStatus }[] = [
    { name: 'resend', label: 'Resend API key', hint: 'Sends confirmations and reminders.', status: data?.email },
    { name: 'telegram-token', label: 'Telegram bot token', hint: 'Optional — booking alerts on your phone.', status: data?.telegramToken },
    { name: 'telegram-chat', label: 'Telegram chat ID', hint: 'Found for you once someone presses Start on the bot.', status: data?.telegramChat },
  ]

  return (
    <div className="card">
      <div className="row" style={{ justifyContent: 'space-between', alignItems: 'flex-start' }}>
        <div>
          <h2 className="card-title">Connected services</h2>
          <p className="card-sub" style={{ marginBottom: 0 }}>
            Sending from <strong>{data?.mailFrom ?? '—'}</strong>
            {data?.replyTo && <> · replies to {data.replyTo}</>}
          </p>
        </div>
        <button type="button" className="btn btn-sm" disabled={check.isPending} onClick={() => check.mutate()}>
          {check.isPending ? 'Checking…' : 'Test email key'}
        </button>
      </div>

      {telegram.data && !telegram.data.ok && telegram.data.hasToken && (
        <div className="banner banner-info" style={{ marginTop: 14 }}>
          <strong>{telegram.data.message}</strong>
          {telegram.data.fix && <div style={{ marginTop: 4 }}>{telegram.data.fix}</div>}

          {telegram.data.chats.length > 0 ? (
            <div className="row" style={{ marginTop: 10, flexWrap: 'wrap' }}>
              {telegram.data.chats.map((c) => (
                <button
                  key={c.id}
                  type="button"
                  className="btn btn-sm"
                  disabled={useChat.isPending}
                  onClick={() => useChat.mutate(c.id)}
                >
                  Send alerts to {c.label}
                </button>
              ))}
            </div>
          ) : (
            <button
              type="button"
              className="btn btn-sm"
              style={{ marginTop: 10 }}
              disabled={telegram.isFetching}
              onClick={() => void telegram.refetch()}
            >
              {telegram.isFetching ? 'Looking…' : 'Find my chat'}
            </button>
          )}
        </div>
      )}

      {telegram.data?.ok && (
        <div className="row" style={{ marginTop: 12 }}>
          <span className="small muted">Phone alerts: {telegram.data.message}</span>
          <button
            type="button"
            className="btn btn-sm"
            disabled={telegramTest.isPending}
            onClick={() => telegramTest.mutate()}
          >
            {telegramTest.isPending ? 'Sending…' : 'Send a test message'}
          </button>
        </div>
      )}

      {health.data && (!health.data.ok || health.data.recentFailures.length > 0) && (
        // Danger only when mail is actually failing now. Old failures under a configuration that
        // has since been fixed are a tidy-up, not an emergency, and colouring them red trains
        // the studio to ignore the banner that will one day matter.
        <div
          className={`banner ${health.data.ok ? 'banner-info' : 'banner-danger'}`}
          style={{ marginTop: 14 }}
          role={health.data.ok ? undefined : 'alert'}
        >
          <strong>{health.data.message}</strong>
          {health.data.fix && <div style={{ marginTop: 4 }}>{health.data.fix}</div>}

          {health.data.recentFailures.length > 0 && (
            <>
              <details style={{ marginTop: 8 }}>
                <summary>What failed{health.data.ok ? ' before' : ' most recently'}</summary>
                <ul style={{ margin: '6px 0 0' }}>
                  {health.data.recentFailures.map((f, i) => (
                    <li key={i} className="small">
                      <strong>{f.type}</strong> to {f.to || '—'} — {f.error}
                    </li>
                  ))}
                </ul>
              </details>

              <button
                type="button"
                className="btn btn-sm"
                style={{ marginTop: 10 }}
                disabled={clearFailures.isPending}
                onClick={() => clearFailures.mutate()}
              >
                {clearFailures.isPending ? 'Clearing…' : 'Clear these'}
              </button>
            </>
          )}
        </div>
      )}

      <div className="field-row" style={{ marginTop: 14 }}>
        <MailField
          label="Send from"
          name="mail-from"
          value={data?.mailFrom ?? ''}
          hint={
            health.data?.verifiedDomains.length
              ? `Must be an address at a domain verified in Resend: ${health.data.verifiedDomains.join(', ')}.`
              : 'Must be an address at a domain verified in Resend. Resend\'s own test address only ever reaches the Resend account owner.'
          }
          onSaved={() => {
            void queryClient.invalidateQueries({ queryKey: ['integrations'] })
            void health.refetch()
          }}
          onMessage={onMessage}
        />
      </div>
      <p className="field-hint">Replies go to {data?.replyTo || 'the studio contact email'}. Change this in Studio details above.</p>

      <div className="table-wrap">
        <table className="table" style={{ marginTop: 14 }}>
          <tbody>
            {rows.map((row) => (
              <tr key={row.name}>
                <td>
                  <div className="row-title">{row.label}</div>
                  <div className="row-sub">{row.hint}</div>
  
                  {editing === row.name && (
                    <div className="row" style={{ marginTop: 10 }}>
                      <input
                        type="password"
                        autoFocus
                        className="btn"
                        style={{ minWidth: 300, fontFamily: 'ui-monospace, monospace' }}
                        placeholder="Paste the new key"
                        value={value}
                        onChange={(e) => setValue(e.target.value)}
                      />
                      <button
                        type="button"
                        className="btn btn-primary btn-sm"
                        disabled={!value.trim() || save.isPending}
                        onClick={() => save.mutate({ name: row.name, value: value.trim() })}
                      >
                        Save
                      </button>
                      <button type="button" className="btn btn-sm" onClick={() => { setEditing(null); setValue('') }}>
                        Cancel
                      </button>
                    </div>
                  )}
                </td>
                <td style={{ textAlign: 'right', whiteSpace: 'nowrap' }}>
                  {row.status?.configured ? (
                    <>
                      <span className="mono faint" style={{ marginRight: 8 }}>{row.status.hint}</span>
                      <span className={row.status.source === 'studio' ? 'pill pill-ok' : 'pill pill-muted'}>
                        {row.status.source === 'studio' ? 'Set here' : 'From server'}
                      </span>
                    </>
                  ) : (
                    <span className="pill pill-warn">Not set</span>
                  )}
                  {editing !== row.name && (
                    <button
                      type="button"
                      className="btn btn-sm"
                      style={{ marginLeft: 8 }}
                      onClick={() => { setEditing(row.name); setValue('') }}
                    >
                      Change
                    </button>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="banner banner-info" style={{ marginTop: 14, marginBottom: 0 }}>
        Keys are stored encrypted and never shown again once saved — only the first and last few
        characters, so you can tell which key is in place.
      </div>
    </div>
  )
}

/** One editable mail address, saved on blur so there is no separate save button to miss. */
function MailField({
  label,
  name,
  value,
  hint,
  onSaved,
  onMessage,
}: {
  label: string
  name: string
  value: string
  hint: string
  onSaved: () => void
  onMessage: (m: { kind: 'ok' | 'danger'; text: string }) => void
}) {
  const save = useMutation({
    mutationFn: (next: string) => api.put(`/api/admin/settings/mail/${name}`, { value: next }),
    onSuccess: () => { onMessage({ kind: 'ok', text: 'Saved.' }); onSaved() },
    onError: (err) => onMessage({ kind: 'danger', text: err instanceof ApiError ? err.message : 'Could not save.' }),
  })

  return (
    <label className="field">
      <span>{label}</span>
      <input
        defaultValue={value}
        key={value}
        onBlur={(e) => { if (e.target.value !== value) save.mutate(e.target.value) }}
      />
      <div className="field-hint">{hint}</div>
    </label>
  )
}

interface BackupFile { file: string; bytes: number; createdAt: string }

/**
 * Nightly backups.
 *
 * MongoDB's free tier takes none, so the app takes its own onto this server's disk. Shown here
 * because a backup job that quietly stopped looks exactly like one that is working, right up
 * until the day it is needed.
 */
function BackupsCard({ onMessage }: { onMessage: (m: { kind: 'ok' | 'danger'; text: string }) => void }) {
  const queryClient = useQueryClient()

  const { data } = useQuery({
    queryKey: ['backups'],
    queryFn: () => api.get<{ backups: BackupFile[]; ageHours: number | null; keep: number }>('/api/admin/settings/backups'),
  })

  const run = useMutation({
    mutationFn: () => api.post<{ file: string; totalDocuments: number }>('/api/admin/settings/backups/run'),
    onSuccess: (r) => {
      onMessage({ kind: 'ok', text: `Backed up ${r.totalDocuments} records to ${r.file}.` })
      void queryClient.invalidateQueries({ queryKey: ['backups'] })
    },
    onError: (err) => onMessage({ kind: 'danger', text: err instanceof ApiError ? err.message : 'Backup failed.' }),
  })

  const backups = data?.backups ?? []
  const stale = data?.ageHours === null || (data?.ageHours ?? 0) > 48

  return (
    <div className="card">
      <div className="row" style={{ justifyContent: 'space-between', alignItems: 'flex-start' }}>
        <div>
          <h2 className="card-title">Backups</h2>
          <p className="card-sub" style={{ marginBottom: 0 }}>
            Taken automatically every night, and kept for the last {data?.keep ?? 30} days.
          </p>
        </div>
        <button type="button" className="btn btn-sm" disabled={run.isPending} onClick={() => run.mutate()}>
          {run.isPending ? 'Backing up…' : 'Back up now'}
        </button>
      </div>

      {stale && (
        <div className="banner banner-danger" style={{ marginTop: 14 }}>
          {data?.ageHours === null
            ? 'No backup has been taken yet. Your bookings could not be recovered if the database were lost.'
            : 'The nightly backup has not run in over two days.'}
        </div>
      )}

      {backups.length > 0 && (
        <div className="table-wrap">
          <table className="table" style={{ marginTop: 14 }}>
            <tbody>
              {backups.slice(0, 8).map((b) => (
                <tr key={b.file}>
                  <td>
                    <div className="row-title">
                      {DateTime.fromISO(b.createdAt).setZone(STUDIO_TZ).toFormat('ccc d LLL yyyy, h:mm a')}
                    </div>
                    <div className="row-sub">{(b.bytes / 1024).toFixed(0)} KB</div>
                  </td>
                  <td style={{ textAlign: 'right' }}>
                    <a className="btn btn-sm" href={`/api/admin/settings/backups/${b.file}`} download>
                      Download
                    </a>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  )
}

function PushEnrolment({ onMessage }: { onMessage: (m: { kind: 'ok' | 'danger'; text: string }) => void }) {
  const [busy, setBusy] = useState(false)

  async function enable() {
    setBusy(true)
    try {
      const { publicKey } = await api.get<{ publicKey: string | null }>('/api/admin/settings/push/key')
      if (!publicKey) {
        onMessage({ kind: 'danger', text: 'Push alerts are not configured on the server yet.' })
        return
      }

      const permission = await Notification.requestPermission()
      if (permission !== 'granted') {
        onMessage({ kind: 'danger', text: 'Your browser blocked notifications.' })
        return
      }

      const registration = await navigator.serviceWorker.register('/admin/sw.js')
      const subscription = await registration.pushManager.subscribe({
        userVisibleOnly: true,
        applicationServerKey: publicKey,
      })

      await api.post('/api/admin/settings/push/subscribe', subscription.toJSON())
      onMessage({ kind: 'ok', text: 'Push alerts are on for this device.' })
    } catch (err) {
      onMessage({ kind: 'danger', text: err instanceof Error ? err.message : 'Could not turn on push alerts.' })
    } finally {
      setBusy(false)
    }
  }

  const supported = 'serviceWorker' in navigator && 'PushManager' in window

  if (!supported) {
    return <p className="muted small">This browser does not support push notifications.</p>
  }

  return (
    <button type="button" className="btn" onClick={enable} disabled={busy}>
      {busy ? 'Setting up…' : 'Turn on push alerts for this device'}
    </button>
  )
}

/** Change your own password. Signs every session out afterwards, including this one. */
function ChangePassword({ onMessage }: { onMessage: (m: { kind: 'ok' | 'danger'; text: string }) => void }) {
  const [open, setOpen] = useState(false)
  const [form, setForm] = useState({ currentPassword: '', newPassword: '', confirm: '' })

  const change = useMutation({
    mutationFn: () =>
      api.post<{ message: string }>('/api/auth/admin/password', {
        currentPassword: form.currentPassword,
        newPassword: form.newPassword,
      }),
    onSuccess: () => {
      onMessage({ kind: 'ok', text: 'Password changed. Signing you out…' })
      setTimeout(() => window.location.reload(), 1200)
    },
    onError: (err) =>
      onMessage({ kind: 'danger', text: err instanceof ApiError ? err.message : 'Could not change your password.' }),
  })

  const mismatch = form.confirm.length > 0 && form.newPassword !== form.confirm
  const canSubmit =
    form.currentPassword.length > 0 && form.newPassword.length >= 12 && form.newPassword === form.confirm

  if (!open) {
    return (
      <button type="button" className="btn" onClick={() => setOpen(true)}>
        Change password
      </button>
    )
  }

  return (
    <div style={{ maxWidth: 360 }}>
      <PasswordField
        label="Current password"
        value={form.currentPassword}
        onChange={(v) => setForm({ ...form, currentPassword: v })}
        autoFocus
      />
      <PasswordField
        label="New password"
        value={form.newPassword}
        onChange={(v) => setForm({ ...form, newPassword: v })}
        autoComplete="new-password"
        minLength={12}
        hint="At least 12 characters."
      />
      <PasswordField
        label="Confirm new password"
        value={form.confirm}
        onChange={(v) => setForm({ ...form, confirm: v })}
        autoComplete="new-password"
        hint={mismatch ? 'These do not match.' : undefined}
      />

      <div className="row">
        <button
          type="button"
          className="btn btn-primary"
          disabled={!canSubmit || change.isPending}
          onClick={() => change.mutate()}
        >
          {change.isPending ? 'Changing…' : 'Change password'}
        </button>
        <button type="button" className="btn" onClick={() => setOpen(false)}>Cancel</button>
      </div>

      <div className="field-hint" style={{ marginTop: 10 }}>
        You will be signed out on every device, including this one.
      </div>
    </div>
  )
}

function TotpSetup({ onMessage }: { onMessage: (m: { kind: 'ok' | 'danger'; text: string }) => void }) {
  const [secret, setSecret] = useState<string | null>(null)
  const [code, setCode] = useState('')

  const setupMutation = useMutation({
    mutationFn: () => api.post<{ secret: string; otpauthUrl: string }>('/api/auth/admin/totp/setup'),
    onSuccess: (data) => setSecret(data.secret),
  })

  const confirmMutation = useMutation({
    mutationFn: () => api.post('/api/auth/admin/totp/confirm', { totp: code }),
    onSuccess: () => {
      onMessage({ kind: 'ok', text: 'Two-factor sign-in is now on.' })
      window.location.reload()
    },
    onError: (err) =>
      onMessage({ kind: 'danger', text: err instanceof ApiError ? err.message : 'That code was not accepted.' }),
  })

  if (!secret) {
    return (
      <button type="button" className="btn" onClick={() => setupMutation.mutate()} disabled={setupMutation.isPending}>
        Set up two-factor sign-in
      </button>
    )
  }

  return (
    <div className="stack">
      <p className="small">
        In your authenticator app, add an account by entering this key:
      </p>
      <div className="mono" style={{ padding: 10, background: 'var(--canvas)', borderRadius: 8, wordBreak: 'break-all' }}>
        {secret}
      </div>
      <div className="row">
        <input
          className="btn"
          style={{ width: 130 }}
          inputMode="numeric"
          maxLength={6}
          placeholder="000000"
          value={code}
          onChange={(e) => setCode(e.target.value.replace(/\D/g, ''))}
        />
        <button type="button" className="btn btn-primary" disabled={code.length !== 6 || confirmMutation.isPending} onClick={() => confirmMutation.mutate()}>
          Confirm
        </button>
      </div>
    </div>
  )
}

/**
 * Add a course.
 *
 * The two fields that decide whether a course can actually be sold — the shop product and
 * whether the studio approves each payment — are on the form rather than left to be discovered
 * afterwards. A course created without a product looks finished but silently cannot be booked,
 * which is the failure the Autumn Ikebana Course already hit.
 */
function NewCourseForm({
  onMessage,
}: {
  onMessage: (m: { kind: 'ok' | 'danger'; text: string }) => void
}) {
  const queryClient = useQueryClient()
  const [open, setOpen] = useState(false)
  const [form, setForm] = useState({
    name: '',
    colour: '#7c6a9c',
    bookingMode: 'paid' as 'paid' | 'package' | 'free',
    checkoutFlow: 'calendar_checkout' as 'calendar_checkout' | 'product_page',
    rescheduleCutoffHours: 72,
    defaultDurationMins: 150,
    defaultCapacity: 8,
    wooProductUrl: '',
    requiresManualConfirmation: true,
  })

  const create = useMutation({
    mutationFn: () =>
      api.post('/api/admin/settings/courses', {
        name: form.name.trim(),
        // Derived rather than asked for: the slug is only ever used in URLs and the shortcode,
        // and asking the studio to invent one is asking them to get it wrong.
        slug: form.name
          .trim()
          .toLowerCase()
          .replace(/[^a-z0-9]+/g, '-')
          .replace(/^-|-$/g, ''),
        colour: form.colour,
        bookingMode: form.bookingMode,
        checkoutFlow: form.checkoutFlow,
        rescheduleCutoffHours: form.rescheduleCutoffHours,
        cancelCutoffHours: form.rescheduleCutoffHours,
        defaultDurationMins: form.defaultDurationMins,
        defaultCapacity: form.defaultCapacity,
        wooProductIds: [],
        wooProductUrl: form.wooProductUrl.trim(),
        requiresManualConfirmation: form.bookingMode === 'free' ? false : form.requiresManualConfirmation,
      }),
    onSuccess: () => {
      onMessage({ kind: 'ok', text: `${form.name} added. Add classes for it on the calendar.` })
      setForm({ ...form, name: '', wooProductUrl: '' })
      setOpen(false)
      void queryClient.invalidateQueries({ queryKey: ['courses'] })
    },
    onError: (err) =>
      onMessage({
        kind: 'danger',
        text: err instanceof ApiError ? err.message : 'That course could not be added.',
      }),
  })

  if (!open) {
    return (
      <button type="button" className="btn btn-quiet" style={{ marginTop: 14 }} onClick={() => setOpen(true)}>
        + Add a course
      </button>
    )
  }

  return (
    <form
      className="inline-form"
      onSubmit={(e) => {
        e.preventDefault()
        create.mutate()
      }}
    >
      <label className="field">
        <span>Course name</span>
        <input
          value={form.name}
          onChange={(e) => setForm({ ...form, name: e.target.value })}
          placeholder="Preserved Flower"
          required
          autoFocus
        />
      </label>

      <label className="field" style={{ flex: '0 0 130px' }}>
        <span>Paid how?</span>
        <select
          value={form.bookingMode}
          onChange={(e) => setForm({ ...form, bookingMode: e.target.value as typeof form.bookingMode })}
        >
          <option value="paid">In the shop</option>
          <option value="package">Course package</option>
          <option value="free">Free</option>
        </select>
      </label>

      <label className="field" style={{ flex: '1 1 320px' }}>
        <span>Shop product link</span>
        <input
          type="url"
          value={form.wooProductUrl}
          onChange={(e) => setForm({ ...form, wooProductUrl: e.target.value })}
          placeholder="https://mizuki.com.sg/product/…"
          disabled={form.bookingMode === 'free'}
        />
        <span className="field-hint">Paste the public WooCommerce product page. Its product code and current price are added automatically.</span>
      </label>

      {form.bookingMode === 'paid' && (
        <label className="field" style={{ flex: '0 0 220px' }}>
          <span>Checkout route</span>
          <select
            value={form.checkoutFlow}
            onChange={(e) => setForm({ ...form, checkoutFlow: e.target.value as typeof form.checkoutFlow })}
          >
            <option value="calendar_checkout">Calendar then payment</option>
            <option value="product_page">Product page options</option>
          </select>
        </label>
      )}

      <label className="field" style={{ flex: '0 0 96px' }}>
        <span>Class size</span>
        <input
          type="number"
          min={1}
          max={200}
          value={form.defaultCapacity}
          onChange={(e) => setForm({ ...form, defaultCapacity: Number(e.target.value) })}
        />
      </label>

      <label className="field" style={{ flex: '0 0 116px' }}>
        <span>Notice to change</span>
        <select
          value={form.rescheduleCutoffHours}
          onChange={(e) => setForm({ ...form, rescheduleCutoffHours: Number(e.target.value) })}
        >
          <option value={0}>No restriction</option>
          <option value={24}>24 hours</option>
          <option value={48}>2 days</option>
          <option value={72}>3 days</option>
          <option value={168}>1 week</option>
        </select>
      </label>

      <label className="field" style={{ flex: '1 1 210px' }}>
        <span>Colour</span>
        <input
          type="color"
          value={form.colour}
          onChange={(e) => setForm({ ...form, colour: e.target.value })}
        />
      </label>

      {form.bookingMode !== 'free' && (
        <label className="switch-label" style={{ flex: '1 1 100%' }}>
          <input
            type="checkbox"
            checked={form.requiresManualConfirmation}
            onChange={(e) => setForm({ ...form, requiresManualConfirmation: e.target.checked })}
          />
          <span className="small">
            I check each payment myself before confirming the place
          </span>
        </label>
      )}

      <div className="row" style={{ flex: '1 1 100%' }}>
        <button type="submit" className="btn btn-primary" disabled={create.isPending || !form.name.trim()}>
          Add course
        </button>
        <button type="button" className="btn btn-quiet" onClick={() => setOpen(false)}>
          Cancel
        </button>
      </div>
    </form>
  )
}
