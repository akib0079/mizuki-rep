# Going live

Ordered by what blocks launch, not by effort. Nothing here is written yet in production —
everything so far has run against a local database with invented students.

## 1. Needed from the studio

Four of these the system cannot guess, and one of them silently breaks the shop if it is missed.

| | Why it matters |
|---|---|
| **Class size per course** | Every seeded class currently uses a placeholder of **8**. If the Ikebana room really holds 6, the calendar will sell 8 places. Set per course under Settings, and per class on the calendar. |
| **WooCommerce product IDs** | For each paid workshop, each course package, and **the Autumn Ikebana Course**. Until the Autumn course has its product id, buying it in the shop books nothing at all — the order arrives with no way to tell what it was for. |
| **Dates already closed** | Holidays and away days through the rest of the year, so they never appear as bookable. |
| **Sun 27 Sept — is there an Ikebana workshop?** | October has both a 4th-weekend course morning (24th) and a Sunday two-session day (25th). September has the 26th but no 27th. Probably deliberate — worth one line of confirmation. |
| **Is "3 days" exact hours?** | Built as 72 hours, so a Saturday 10:00 class locks Wednesday 10:00 — matching the studio's own example. If they mean whole calendar days, it is one setting. |

## 2. Accounts to open

**MongoDB Atlas** — see the note on tier below.

**Resend**, for email. The free tier covers 3,000 messages a month, which is well beyond a
studio this size. Deliberately not Hostinger's SMTP: shared-host mail is rate-limited and lands
in spam, and a class reminder that quietly never arrives is worse than not offering reminders.

**Telegram bot** (optional, 2 minutes) — message @BotFather, then @userinfobot for the chat id.
This is what makes "notify me when someone books" an actual phone alert rather than another
email in the pile.

## 3. DNS

Two records on `mizuki.com.sg`:

- **A / CNAME** for `api.mizuki.com.sg`, pointing at the Hostinger Node app.
- **SPF and DKIM** for Resend. Without these, confirmations and reminders go to spam — which
  looks identical to the system being broken.

Once the domain verifies, the sending address has to move onto it — and that address is **not**
`MAIL_FROM` in the environment. Whatever was last saved under Settings → Email in the console
lives in the database and wins over the environment every time, so changing the deployed
environment variable and restarting appears to work and changes nothing. Set it in the console:
Settings → Email → Send from → `bookings@mizuki.com.sg`.

It matters most at exactly this moment. A new Resend key is scoped to the domains that key's
account has verified, so a key issued for `mizuki.com.sg` cannot send from anywhere else — swap
the key while the stored address still points at the old domain and *every* message is rejected.
The console refuses an address it cannot send from at the moment you save it, and the outbox
reports the rejection rather than retrying it, but neither helps if nobody goes and changes it.

Both domains must be on HTTPS. The student session cookie is `SameSite=None; Secure` in
production, because the widget runs on the WordPress site and calls the API on a subdomain;
browsers drop that cookie entirely over plain HTTP.

## 4. Deploy

```bash
# Hostinger hPanel → Websites → Add Website → Node.js, on api.mizuki.com.sg
# Deploy from GitHub, then set the environment variables from apps/api/.env.example
npm run seed          # courses, weekly timetable, weekend workshops, email templates
npm run create-admin  # the studio's sign-in — interactive, so no password in shell history
```

One hPanel cron entry, every five minutes. This is what sends reminders, releases unpaid holds,
keeps the three-month calendar filled and posts the morning digest:

```bash
curl -fsS -X POST https://api.mizuki.com.sg/api/jobs/tick -H "X-Cron-Secret: YOUR_CRON_SECRET"
```

WordPress:

```bash
npm run package:wp    # produces wp-plugin/mizuki-booking-bridge.zip
```

Upload under Plugins → Add New → Upload, activate, then Settings → Mizuki Booking: enter the API
address and a shared secret matching `WOO_WEBHOOK_SECRET`. Put `[mizuki_booking]` on the booking
page and `[mizuki_my_bookings]` on a "My bookings" page.

## 5. The database tier

**Atlas M0 (free) is fine**, now that the app takes its own backups.

The studio's entire year of timetable data is **75 KB**. Projecting real use — a few thousand
bookings a year — the free tier's 512 MB holds decades. Storage was never the constraint.

The one real gap in M0 is that it takes no backups. The app now closes that itself: every night
at 03:00 it writes a full compressed export to this server's disk, keeps the last 30, and prunes
sent messages older than 90 days. That copy lives on Hostinger rather than in Atlas, so it is a
genuine second location rather than the same risk twice.

Restore with:

```bash
npm run restore -- mizuki-2026-10-01T0300.json.gz
```

The export is Extended JSON, so ids and dates come back as real types rather than strings — a
restore that inserted them as text would look successful and leave every date unqueryable. There
is a test that wipes the database, restores from a real backup file, and checks the same records
come back.

Two things to still do on Atlas:

- Restrict **Network Access** to the Hostinger app's IP rather than leaving it open.
- Download a backup from Settings occasionally and keep it somewhere else, so a lost Hostinger
  account does not take the backups with it.

M0 pauses after 60 days of inactivity, which will not happen here — cron touches it every five
minutes. If the studio grows to the point where losing a day of bookings matters more than
US$9/month, M2 adds Atlas-side daily snapshots on top.

## 6. Before opening it to students

- [ ] Clear the demo data — 8 invented students and ~58 bookings, including a deliberately
      over-capacity class. `npm run seed` does not remove them.
- [ ] Set the real class sizes, then check the calendar shows what the studio expects.
- [ ] Send a test of each email template to a real inbox and confirm it lands in **Inbox**, not
      spam. Check the `.ics` attachment opens in both Google and Apple Calendar.
- [ ] Book a paid workshop end to end with a WooCommerce test order: place held → paid →
      confirmed → confirmation email → appears on the studio calendar.
- [ ] Abandon a checkout and confirm the place returns after the hold window.
- [ ] Reschedule as a student, and confirm the 24h/72h rules behave as the studio expects.
- [ ] Turn on two-factor sign-in for the studio account (Settings → Security).
- [ ] Confirm the cron is firing — `/api/jobs/tick` returns counts, and the morning digest
      arrives the next day.

## 7. Known limits

**Not tested on Hostinger.** Everything here has run locally against a real MongoDB. The Node
app, the cron, and the WordPress plugin have not been exercised on the actual host, and that is
where surprises usually live — file permissions, environment variables, cold starts.

**No staging environment.** Worth pointing a second Hostinger site and a separate Atlas database
at the same repo before changing anything once students are relying on it.

**Load is untested beyond a sanity check.** For a studio of this size that is almost certainly
fine — but the calendar endpoint is the one to watch if a workshop is ever promoted widely.

**Undo has no time limit.** A cancelled class can be restored at any point while it is still in
the future. That is deliberate, but it means a class cancelled by mistake three weeks ago can
still be brought back with its students re-booked, which may surprise someone.
