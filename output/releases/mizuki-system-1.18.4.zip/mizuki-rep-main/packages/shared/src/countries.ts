/**
 * Dialling codes, so a student outside Singapore can leave a number the studio can actually ring.
 *
 * Only the codes are stored here. Country *names* come from Intl.DisplayNames at runtime, which
 * every browser and Node build in use already carries — writing 240 names into this file would be
 * a second copy of a list the platform maintains, in English only, that nobody would ever update.
 */

/** ISO 3166-1 alpha-2 → international dialling code, without the +. */
const DIAL_CODES: Record<string, string> = {
  AD: '376', AE: '971', AF: '93', AG: '1268', AI: '1264', AL: '355', AM: '374', AO: '244',
  AR: '54', AS: '1684', AT: '43', AU: '61', AW: '297', AZ: '994', BA: '387', BB: '1246',
  BD: '880', BE: '32', BF: '226', BG: '359', BH: '973', BI: '257', BJ: '229', BM: '1441',
  BN: '673', BO: '591', BR: '55', BS: '1242', BT: '975', BW: '267', BY: '375', BZ: '501',
  CA: '1', CD: '243', CF: '236', CG: '242', CH: '41', CI: '225', CK: '682', CL: '56',
  CM: '237', CN: '86', CO: '57', CR: '506', CU: '53', CV: '238', CW: '599', CY: '357',
  CZ: '420', DE: '49', DJ: '253', DK: '45', DM: '1767', DO: '1809', DZ: '213', EC: '593',
  EE: '372', EG: '20', ER: '291', ES: '34', ET: '251', FI: '358', FJ: '679', FM: '691',
  FO: '298', FR: '33', GA: '241', GB: '44', GD: '1473', GE: '995', GF: '594', GG: '44',
  GH: '233', GI: '350', GL: '299', GM: '220', GN: '224', GP: '590', GQ: '240', GR: '30',
  GT: '502', GU: '1671', GW: '245', GY: '592', HK: '852', HN: '504', HR: '385', HT: '509',
  HU: '36', ID: '62', IE: '353', IL: '972', IM: '44', IN: '91', IQ: '964', IR: '98',
  IS: '354', IT: '39', JE: '44', JM: '1876', JO: '962', JP: '81', KE: '254', KG: '996',
  KH: '855', KI: '686', KM: '269', KN: '1869', KR: '82', KW: '965', KY: '1345', KZ: '7',
  LA: '856', LB: '961', LC: '1758', LI: '423', LK: '94', LR: '231', LS: '266', LT: '370',
  LU: '352', LV: '371', LY: '218', MA: '212', MC: '377', MD: '373', ME: '382', MG: '261',
  MH: '692', MK: '389', ML: '223', MM: '95', MN: '976', MO: '853', MP: '1670', MQ: '596',
  MR: '222', MT: '356', MU: '230', MV: '960', MW: '265', MX: '52', MY: '60', MZ: '258',
  NA: '264', NC: '687', NE: '227', NG: '234', NI: '505', NL: '31', NO: '47', NP: '977',
  NR: '674', NU: '683', NZ: '64', OM: '968', PA: '507', PE: '51', PF: '689', PG: '675',
  PH: '63', PK: '92', PL: '48', PM: '508', PR: '1787', PS: '970', PT: '351', PW: '680',
  PY: '595', QA: '974', RE: '262', RO: '40', RS: '381', RU: '7', RW: '250', SA: '966',
  SB: '677', SC: '248', SD: '249', SE: '46', SG: '65', SI: '386', SK: '421', SL: '232',
  SM: '378', SN: '221', SO: '252', SR: '597', SS: '211', ST: '239', SV: '503', SY: '963',
  SZ: '268', TC: '1649', TD: '235', TG: '228', TH: '66', TJ: '992', TL: '670', TM: '993',
  TN: '216', TO: '676', TR: '90', TT: '1868', TV: '688', TW: '886', TZ: '255', UA: '380',
  UG: '256', US: '1', UY: '598', UZ: '998', VA: '39', VC: '1784', VE: '58', VG: '1284',
  VI: '1340', VN: '84', VU: '678', WS: '685', YE: '967', ZA: '27', ZM: '260', ZW: '263',
}

export const STUDIO_COUNTRY = 'SG'

export interface Country {
  code: string
  name: string
  dial: string
}

/**
 * Where a country's flag lives, under whatever host is serving /flags.
 *
 * Flat artwork rather than the flag emoji. An emoji flag is drawn by the operating system, so the
 * same page shows Apple's glossy waving version on a Mac, a flat one on Android, and — because
 * Windows ships no flag glyphs at all — the bare letters "SG" on the studio's own laptop. A file
 * we serve looks the same everywhere and matches the rest of the interface.
 *
 * Anything that cannot be a country code is stripped rather than passed through: this value ends
 * up in a URL.
 */
export function flagFile(code: string): string {
  return `${code.toLowerCase().replace(/[^a-z]/g, '')}.svg`
}

/** A country's name in English, from the platform's own list. */
function countryName(code: string): string {
  try {
    return new Intl.DisplayNames(['en'], { type: 'region' }).of(code) ?? code
  } catch {
    return code
  }
}

/**
 * Every country, Singapore first and the rest alphabetical.
 *
 * Singapore leads because it is where nearly every student is; the alphabet is for the ones who
 * are not, and scrolling past two hundred names to find the obvious answer is not a design.
 */
export function countryList(): Country[] {
  const all = Object.keys(DIAL_CODES).map((code) => ({
    code,
    name: countryName(code),
    dial: DIAL_CODES[code]!,
  }))

  const home = all.filter((c) => c.code === STUDIO_COUNTRY)
  const rest = all.filter((c) => c.code !== STUDIO_COUNTRY).sort((a, b) => a.name.localeCompare(b.name))
  return [...home, ...rest]
}

export function dialCode(code: string): string | null {
  return DIAL_CODES[code.toUpperCase()] ?? null
}

/** "+65 9123 4567" — how a number is written once we know where it is from. */
export function formatInternational(country: string | null | undefined, phone: string): string {
  const dial = country ? dialCode(country) : null
  if (!dial) return phone

  // Already carries a +, so it was stored international and needs nothing adding.
  if (phone.trim().startsWith('+')) return phone.trim()

  const local = phone.replace(/^0+/, '').trim()
  return `+${dial} ${local}`
}
